// Abstract class for all ink objects
public abstract class Ink {
    String type;

    public String getType() {
        return type;
    }
}