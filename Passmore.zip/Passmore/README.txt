Luke Austin La'akea Passmore
lpassmore3@gatech.edu
Java Version: Java 1.8.0_101

*Note when testing the application:

    - My "blank back of a page" used is the turning
      animations is just a white rectangle that is the
      height of the page. Using this white rectangle does
      not make for a visually appealing animation, but
      it does simulate seeing the back of a turning page.

    